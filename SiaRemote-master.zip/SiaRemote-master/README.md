This is basically a Repo for the Android Studio project files made for SIA 17/18
The project ist based heavily on an already open source appliaction project, so dedicate all credit to the original user: https://github.com/plastygrove/BlueSerial
